
import React, { useState, useEffect } from 'react';
import AdviceChat from './components/AdviceChat';
import DailyZen from './components/DailyZen';
import SageStats from './components/SageStats';
import { Sparkles, Brain, Moon, Sun, ShieldCheck } from 'lucide-react';
import { HarmonyData } from './types';

const App: React.FC = () => {
  const [harmonyHistory, setHarmonyHistory] = useState<HarmonyData[]>([]);

  useEffect(() => {
    // Initial dummy data
    const initialData = Array.from({ length: 12 }, (_, i) => ({
      time: `${i}:00`,
      depth: Math.floor(Math.random() * 40) + 30
    }));
    setHarmonyHistory(initialData);
  }, []);

  const addHarmonyPoint = (depth: number) => {
    setHarmonyHistory(prev => {
      const newData = [...prev.slice(1), { time: new Date().toLocaleTimeString(), depth }];
      return newData;
    });
  };

  return (
    <div className="min-h-screen advice-gradient text-slate-100 pb-12">
      {/* Navigation */}
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center rotate-45">
            <Sparkles className="text-white w-5 h-5 -rotate-45" />
          </div>
          <span className="text-2xl font-bold tracking-tight serif">Aura.</span>
        </div>
        <div className="hidden md:flex items-center space-x-8 text-sm font-medium text-indigo-200">
          <a href="#" className="hover:text-white transition-colors">Philosophy</a>
          <a href="#" className="hover:text-white transition-colors">Meditations</a>
          <a href="#" className="hover:text-white transition-colors">The Forge</a>
          <button className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-full border border-white/10 transition-all flex items-center space-x-2">
            <Brain size={16} />
            <span>Neural Sync</span>
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="max-w-7xl mx-auto px-6 pt-12 pb-24 text-center">
        <div className="inline-flex items-center space-x-2 bg-indigo-500/10 border border-indigo-500/20 px-4 py-1.5 rounded-full mb-6 text-indigo-300 text-xs font-bold uppercase tracking-widest animate-float">
          <ShieldCheck size={14} />
          <span>Hyper-Empathetic AI Architecture</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-bold mb-6 serif tracking-tight">
          Wisdom, <span className="text-indigo-400 italic">Refined.</span>
        </h1>
        <p className="text-indigo-200/70 max-w-2xl mx-auto text-lg md:text-xl font-light leading-relaxed">
          Navigate life's complexities with Aura. A high-intelligence advisor 
          designed to offer clarity, calm, and actionable guidance for the modern soul.
        </p>
      </header>

      {/* Main Content Grid */}
      <main className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Stats and Inspiration */}
        <aside className="lg:col-span-4 space-y-8 order-2 lg:order-1">
          <DailyZen />
          <SageStats data={harmonyHistory} />
          
          <div className="glass rounded-3xl p-8 border border-white/10">
            <h3 className="text-xl font-bold mb-4 serif">The Aura Oath</h3>
            <ul className="space-y-4">
              {[
                { icon: <Sun className="text-amber-400" size={18} />, text: "Seek universal truth over temporary comfort." },
                { icon: <Moon className="text-indigo-400" size={18} />, text: "Acknowledge the shadow to find the light." },
                { icon: <Brain className="text-purple-400" size={18} />, text: "Logic serves the heart, never the other way." }
              ].map((oath, i) => (
                <li key={i} className="flex items-start space-x-3 text-sm text-indigo-200/80 leading-snug">
                  <span className="mt-0.5">{oath.icon}</span>
                  <span>{oath.text}</span>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* Right Column: Chat Interface */}
        <section className="lg:col-span-8 order-1 lg:order-2 h-[800px]">
          <AdviceChat onActivity={addHarmonyPoint} />
        </section>

      </main>

      {/* Footer Quote */}
      <footer className="max-w-7xl mx-auto px-6 mt-24 text-center border-t border-white/5 pt-12">
        <p className="text-indigo-400/50 text-xs uppercase tracking-[0.4em] mb-4 font-bold">Closing Thought</p>
        <blockquote className="serif text-2xl italic text-indigo-100/90 max-w-3xl mx-auto">
          "The greatest wisdom is to see the world as it is, and still find the beauty to love it."
        </blockquote>
        <div className="mt-12 flex justify-center space-x-6 text-indigo-300/40 text-sm">
          <span>&copy; 2024 Aura Wisdom Systems</span>
          <span>&bull;</span>
          <span>Privacy Sanctuary</span>
          <span>&bull;</span>
          <span>Ethical AI Directive</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
