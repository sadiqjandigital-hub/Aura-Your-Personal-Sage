
export enum AdviceCategory {
  LIFE = 'Life',
  CAREER = 'Career',
  RELATIONSHIPS = 'Relationships',
  WELLNESS = 'Wellness',
  FINANCE = 'Finance',
  CREATIVITY = 'Creativity'
}

export interface Message {
  id: string;
  role: 'user' | 'aura';
  content: string;
  timestamp: Date;
  audioUrl?: string;
  category?: AdviceCategory;
}

export interface SageQuote {
  text: string;
  author: string;
}

export interface HarmonyData {
  time: string;
  depth: number;
}
