
import React, { useState, useRef, useEffect } from 'react';
import { Send, Volume2, Sparkles, User, BrainCircuit, Mic } from 'lucide-react';
import { getAdvice, textToSpeech, decodeBase64, decodeAudioData } from '../services/geminiService';
import { Message, AdviceCategory } from '../types';

interface AdviceChatProps {
  onActivity: (depth: number) => void;
}

const AdviceChat: React.FC<AdviceChatProps> = ({ onActivity }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'aura',
      content: "Welcome, seeker. I am Aura. What troubles your spirit today, or what horizon do you seek to reach?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState<AdviceCategory>(AdviceCategory.LIFE);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handlePlayAudio = async (text: string) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const ctx = audioContextRef.current;
      const base64 = await textToSpeech(text);
      if (base64) {
        const bytes = decodeBase64(base64);
        const buffer = await decodeAudioData(bytes, ctx);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (err) {
      console.error("Audio playback error:", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
      category
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    onActivity(Math.random() * 50 + 50);

    const advice = await getAdvice(input, category);
    
    const auraMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'aura',
      content: advice,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, auraMsg]);
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto glass rounded-3xl overflow-hidden shadow-2xl border border-white/10">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center animate-pulse">
            <Sparkles className="text-white w-6 h-6" />
          </div>
          <div>
            <h2 className="font-bold text-lg text-indigo-100 serif">Aura Sage</h2>
            <p className="text-xs text-indigo-300 uppercase tracking-widest font-medium">Wisdom Protocol Active</p>
          </div>
        </div>
        <select 
          value={category}
          onChange={(e) => setCategory(e.target.value as AdviceCategory)}
          className="bg-indigo-900/50 text-indigo-100 text-sm rounded-lg px-3 py-1 outline-none border border-indigo-500/30 focus:border-indigo-500"
        >
          {Object.values(AdviceCategory).map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${m.role === 'user' ? 'bg-indigo-600 ml-3' : 'bg-purple-900 mr-3'}`}>
                {m.role === 'user' ? <User size={16} /> : <BrainCircuit size={16} />}
              </div>
              <div className={`p-4 rounded-2xl ${m.role === 'user' ? 'bg-indigo-600/80 text-white rounded-tr-none' : 'bg-white/10 text-indigo-50 rounded-tl-none border border-white/5'}`}>
                <p className="leading-relaxed text-sm md:text-base whitespace-pre-wrap">{m.content}</p>
                {m.role === 'aura' && (
                  <button 
                    onClick={() => handlePlayAudio(m.content)}
                    className="mt-3 text-indigo-300 hover:text-indigo-100 flex items-center space-x-2 text-xs transition-colors"
                  >
                    <Volume2 size={14} />
                    <span>Listen to Sage</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="flex flex-row items-center space-x-2 bg-white/5 p-4 rounded-2xl rounded-tl-none border border-white/5">
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-100"></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-200"></div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 bg-white/5 border-t border-white/10">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for guidance..."
            className="w-full bg-black/30 text-white border border-white/10 rounded-full py-3 px-6 pr-24 focus:outline-none focus:border-indigo-500 transition-all placeholder-indigo-300/50"
          />
          <div className="absolute right-2 flex space-x-1">
            <button
              type="button"
              className="p-2 text-indigo-400 hover:text-indigo-200 transition-colors"
              title="Voice Input (Coming Soon)"
            >
              <Mic size={20} />
            </button>
            <button
              type="submit"
              disabled={loading}
              className="bg-indigo-600 hover:bg-indigo-500 text-white p-2 rounded-full transition-all disabled:opacity-50"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
        <p className="text-[10px] text-center text-indigo-400/50 mt-2 uppercase tracking-widest">Aura reflects wisdom, but you must choose your own path.</p>
      </form>
    </div>
  );
};

export default AdviceChat;
