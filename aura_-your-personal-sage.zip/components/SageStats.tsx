
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { HarmonyData } from '../types';

interface SageStatsProps {
  data: HarmonyData[];
}

const SageStats: React.FC<SageStatsProps> = ({ data }) => {
  return (
    <div className="glass rounded-3xl p-6 border border-white/10 h-64 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-indigo-100 font-semibold serif">Harmony Index</h3>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          <span className="text-xs text-indigo-300 uppercase tracking-widest">Active Insight</span>
        </div>
      </div>
      <div className="flex-1 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorDepth" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="time" hide />
            <YAxis hide domain={[0, 100]} />
            <Tooltip 
              contentStyle={{ background: 'rgba(15, 23, 42, 0.9)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
              itemStyle={{ color: '#c7d2fe' }}
              labelStyle={{ display: 'none' }}
            />
            <Area 
              type="monotone" 
              dataKey="depth" 
              stroke="#818cf8" 
              fillOpacity={1} 
              fill="url(#colorDepth)" 
              animationDuration={2000}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default SageStats;
