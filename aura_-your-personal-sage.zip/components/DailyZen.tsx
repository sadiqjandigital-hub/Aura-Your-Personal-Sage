
import React, { useState, useEffect } from 'react';
import { RefreshCw, Image as ImageIcon } from 'lucide-react';
import { generateSageImage } from '../services/geminiService';

const DailyZen: React.FC = () => {
  const [imageUrl, setImageUrl] = useState<string>('https://picsum.photos/800/450');
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState("Peaceful Solitude");

  const themes = [
    "Resilience", "Compassion", "Clarity", "Infinite Wisdom", "Inner Peace", 
    "Creative Spark", "Courage", "Mindfulness", "Flow State"
  ];

  const refreshZen = async () => {
    setLoading(true);
    const newTheme = themes[Math.floor(Math.random() * themes.length)];
    setTheme(newTheme);
    const img = await generateSageImage(newTheme);
    setImageUrl(img);
    setLoading(false);
  };

  useEffect(() => {
    refreshZen();
  }, []);

  return (
    <div className="glass rounded-3xl overflow-hidden border border-white/10 group relative">
      <div className="aspect-video relative overflow-hidden">
        {loading ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-indigo-900/20">
            <RefreshCw className="text-indigo-400 w-8 h-8 animate-spin mb-2" />
            <p className="text-xs text-indigo-300 font-medium">Visualizing {theme}...</p>
          </div>
        ) : (
          <img 
            src={imageUrl} 
            alt="Zen Inspiration" 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
        <div className="absolute bottom-4 left-6 right-6">
          <p className="text-indigo-200 text-[10px] uppercase tracking-[0.2em] font-bold mb-1">Visual Inspiration</p>
          <h3 className="text-white text-2xl serif italic">{theme}</h3>
        </div>
        <button 
          onClick={refreshZen}
          className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 p-2 rounded-full transition-all text-white backdrop-blur-md opacity-0 group-hover:opacity-100"
        >
          <RefreshCw size={18} />
        </button>
      </div>
    </div>
  );
};

export default DailyZen;
